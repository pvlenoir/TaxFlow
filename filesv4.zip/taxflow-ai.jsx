import { useState, useMemo, useEffect } from "react";

// ═══════════════════════════════════════════════════════════════════════════
// TAXFLOW AI v3.1 — QA-HARDENED
// Fixes: £ formatter negatives, S24 edge cases, projection inflation,
// portfolio count mismatch, dedup collision, input validation,
// checklist data-complete logic
// ═══════════════════════════════════════════════════════════════════════════

const DISC="This is for educational and informational purposes only and should not be considered tax, legal, or financial advice.";
const OWN={personal:"Personal",company:"Ltd Company",spv:"SPV"};
const BR=0.20,HR=0.40,CT=0.25;
const TH={EXP_H:45,EXP_C:60,INT_H:35,INT_C:50,LTV_H:75,LTV_C:85};
const SK="taxflow-v3";

// ─── FIX #1: £ formatter now shows negatives properly ─────────────────────
const £=(v,sign=false)=>{
  if(typeof v!=="number"||isNaN(v))return "—";
  const neg=v<0;
  const prefix=sign&&v>0?"+":neg?"−":"";
  return`${prefix}£${Math.abs(v).toLocaleString("en-GB",{maximumFractionDigits:0})}`;
};
const P=(v,d=1)=>{if(typeof v!=="number"||isNaN(v))return "—";return`${v.toFixed(d)}%`};

// ─── CALCULATIONS (Section 24-aware) ──────────────────────────────────────
function cm(p){
  const ri=Math.max(0,p.annualGrossRent||0); // FIX #8: floor at 0
  const oc=Math.max(0,(p.annualOperatingExpenses||0)+(p.managementFees||0)+(p.voidAllowance||0)+(p.otherDeductibleCosts||0));
  const fc=Math.max(0,p.annualMortgageInterest||0);
  const pr=Math.max(0,p.annualPrincipalRepayment||0);
  const os=ri-oc;
  const cf=ri-oc-fc-pr;
  const cv=Math.max(1,p.estimatedCurrentValue||p.purchasePrice||1);

  let s24=null;
  if(p.ownershipType==="personal"){
    const rpbc=ri-oc; // can be negative if costs > rent
    const brc=fc*BR;
    const taxAt20=Math.max(0,rpbc*BR-brc);
    const taxAt40=Math.max(0,rpbc*HR-brc);
    const old40=Math.max(0,(rpbc-fc)*HR);
    const s24cost40=Math.max(0,taxAt40-old40); // FIX: floor at 0, never show negative S24 cost
    s24={rpbc,interest:fc,brc,taxAt20,taxAt40,s24cost40};
  }

  let co=null;
  if(p.ownershipType!=="personal"){
    const pbt=ri-oc-fc;
    co={pbt,corpTax:Math.max(0,pbt*CT)};
  }

  return{
    pid:p.id,pname:p.name||"Unnamed",own:p.ownershipType,
    ri,oc,fc,os,cf,s24,co,
    expR:ri>0?(oc/ri)*100:0,
    intR:ri>0?(fc/ri)*100:0,
    gY:cv>0?(ri/cv)*100:0,
    nY:cv>0?(os/cv)*100:0,
    ltv:cv>0?((p.mortgageBalance||0)/cv)*100:0,
    negCF:cf<0,negOS:os<0,
  };
}

// FIX #5: Portfolio calc now separates "all properties" count from "active metrics" count
function cp(ps,ms){
  const s=a=>a.length?a.reduce((x,y)=>x+y,0):0;
  const tri=s(ms.map(m=>m.ri)),toc=s(ms.map(m=>m.oc)),tfc=s(ms.map(m=>m.fc));
  const tos=s(ms.map(m=>m.os)),tcf=s(ms.map(m=>m.cf));
  const tpv=s(ps.filter(p=>p.annualGrossRent>0).map(p=>p.estimatedCurrentValue||p.purchasePrice||0)); // only active properties
  const tmb=s(ps.filter(p=>p.annualGrossRent>0).map(p=>p.mortgageBalance||0));
  const pm=ms.filter(m=>m.s24),cpm=ms.filter(m=>m.co);
  return{tri,toc,tfc,tos,tcf,tpv,tmb,
    pLtv:tpv>0?(tmb/tpv)*100:0,pExpR:tri>0?(toc/tri)*100:0,pIntR:tri>0?(tfc/tri)*100:0,
    pGY:tpv>0?(tri/tpv)*100:0,pNY:tpv>0?(tos/tpv)*100:0,
    cnt:ps.length, activeCnt:ms.length, // FIX: track both
    persCnt:ps.filter(p=>p.ownershipType==="personal"&&p.annualGrossRent>0).length,
    corpCnt:ps.filter(p=>p.ownershipType!=="personal"&&p.annualGrossRent>0).length,
    tPersProfit:s(pm.map(m=>m.s24.rpbc)),tPersInt:s(pm.map(m=>m.s24.interest)),
    tPersBRC:s(pm.map(m=>m.s24.brc)),tCoProfit:s(cpm.map(m=>m.co.pbt)),
  };
}

// ─── RANKINGS ─────────────────────────────────────────────────────────────
function rank(ms){if(ms.length<2)return null;const med=k=>{const v=ms.map(m=>m[k]).sort((a,b)=>a-b);const i=Math.floor(v.length/2);return v.length%2?v[i]:(v[i-1]+v[i])/2};const byD=k=>[...ms].sort((a,b)=>b[k]-a[k]);const byA=k=>[...ms].sort((a,b)=>a[k]-b[k]);const bY=byD("gY"),bC=byD("cf"),bI=byD("intR"),bL=byD("ltv"),bE=byA("expR");return{bestYield:bY[0],worstYield:bY[bY.length-1],bestCF:bC[0],worstCF:bC[bC.length-1],mostRateSensitive:bI[0],mostLeveraged:bL[0],leanest:bE[0],costliest:bE[bE.length-1],medExpR:med("expR"),medIntR:med("intR"),medGY:med("gY"),medCF:med("cf"),rankings:{byYield:bY.map(m=>({pid:m.pid,pn:m.pname,v:m.gY})),byCF:bC.map(m=>({pid:m.pid,pn:m.pname,v:m.cf})),byExpR:byD("expR").map(m=>({pid:m.pid,pn:m.pname,v:m.expR}))}}}

// ─── HEADLINE ─────────────────────────────────────────────────────────────
function headline(ms,port,rk){if(ms.length===0)return{type:"info",text:"Add property data to see your portfolio headline."};const nc=ms.filter(m=>m.negCF).length;const ts=ms.filter(m=>m.s24).reduce((s,m)=>s+(m.s24.s24cost40||0),0);if(nc>ms.length/2)return{type:"critical",text:`${nc} of ${ms.length} properties have negative cash flow. Portfolio consuming more cash than it generates.`};if(ts>3000&&port.persCnt>0)return{type:"warning",text:`Section 24 may be adding ~${£(ts)}/yr to your tax cost across ${port.persCnt} personal ${port.persCnt===1?"property":"properties"} (illustrative, at higher rate).`};if(port.pLtv>80)return{type:"warning",text:`Portfolio leverage is ${P(port.pLtv,0)} — above typical BTL thresholds.`};if(rk?.worstCF?.cf<-3000)return{type:"warning",text:`${rk.worstCF.pname} is draining ${£(Math.abs(rk.worstCF.cf))}/yr — your biggest cash flow risk.`};if(port.tcf>0&&port.pGY>5)return{type:"positive",text:`Positive cash flow of ${£(port.tcf)}/yr at ${P(port.pGY,1)} yield. Focus on efficiency and structure.`};return{type:"info",text:`${£(port.tri)}/yr income across ${port.activeCnt} properties, ${£(port.tcf)}/yr cash flow.`}}

// ─── SCENARIOS ────────────────────────────────────────────────────────────
const PRESETS=[{id:"rate6",name:"Rates Rise to 6%",desc:"All mortgages at 6%",fn:(p)=>{const a={...p};if(p.mortgageBalance>0)a.annualMortgageInterest=p.mortgageBalance*0.06;return a}},{id:"void3m",name:"3-Month Void (Worst)",desc:"Weakest property empty 3 months",fn:(p,isWorst)=>{const a={...p};if(isWorst)a.annualGrossRent=p.annualGrossRent*0.75;return a}},{id:"addAgent",name:"Add Agent (10%)",desc:"Add 10% management fee",fn:(p)=>{const a={...p};if(!p.managementFees)a.managementFees=p.annualGrossRent*0.10;return a}},{id:"rmAgent",name:"Self-Manage",desc:"Remove management fees",fn:(p)=>({...p,managementFees:0})},{id:"maint25",name:"+25% Maintenance",desc:"Operating costs +25%",fn:(p)=>({...p,annualOperatingExpenses:p.annualOperatingExpenses*1.25})},{id:"stress",name:"Stress Test",desc:"6% rate + 10% rent drop + 15% cost rise",fn:(p)=>{const a={...p};a.annualGrossRent=p.annualGrossRent*0.90;a.annualOperatingExpenses=p.annualOperatingExpenses*1.15;if(p.mortgageBalance>0)a.annualMortgageInterest=p.mortgageBalance*0.06;return a}}];

function runPreset(preset,props,worstId){const adj=props.filter(p=>p.annualGrossRent>0).map(p=>preset.fn({...p},p.id===worstId));const ms=adj.map(cm);const pt=cp(adj,ms);return{ms,port:pt}}

// FIX #3: 3-year projection now inflates ALL cost components
function proj3(props,rg=0.02,ci=0.03,rc=0){const active=props.filter(p=>p.annualGrossRent>0);return[0,1,2,3].map(yr=>{const adj=active.map(p=>{const a={...p};const g=Math.pow(1+rg,yr);const c=Math.pow(1+ci,yr);a.annualGrossRent=p.annualGrossRent*g;a.annualOperatingExpenses=p.annualOperatingExpenses*c;a.managementFees=p.managementFees*c; // FIX: was not inflated
a.voidAllowance=p.voidAllowance*c; // FIX: was not inflated
a.otherDeductibleCosts=p.otherDeductibleCosts*c; // FIX: was not inflated
if(rc&&p.mortgageBalance>0){const cr=p.annualMortgageInterest/p.mortgageBalance;a.annualMortgageInterest=p.mortgageBalance*Math.max(0,cr+rc*yr/10000)}return a});const ms=adj.map(cm);const pt=cp(adj,ms);return{yr,label:yr===0?"Current":`Year ${yr}`,ri:pt.tri,os:pt.tos,cf:pt.tcf,gY:pt.pGY}})}

// ─── REVIEW CHECKLIST ─────────────────────────────────────────────────────
// FIX #7: data completeness actually checks key fields, not just rent
function genChecklist(props,ms,port,rk){const items=[];const a=(id,text,pri="normal")=>items.push({id,text,pri});
  const hasAllData=props.every(p=>p.annualGrossRent>0&&(p.estimatedCurrentValue>0||p.purchasePrice>0)&&p.name);
  a("data",`All properties have key data entered${hasAllData?" ✓":""}`,hasAllData?"done":"normal");
  a("expenses","Review operating costs — are all deductible items claimed?");
  a("interest","Confirm interest figures match latest mortgage statements");
  a("values","Update current property values to recent estimates");
  if(port.persCnt>0){a("s24","Discuss Section 24 position with accountant","high");const ts=ms.filter(m=>m.s24).reduce((s,m)=>s+(m.s24?.s24cost40||0),0);if(ts>1000)a("incorp",`Consider incorporation review — illustrative S24 cost: ~${£(ts)}/yr at 40%`,"high")}
  if(rk?.worstCF?.cf<-1000)a("worst",`Review ${rk.worstCF.pname} — worst cash flow at ${£(rk.worstCF.cf)}/yr`,"high");
  if(port.pLtv>75)a("ltv",`Portfolio LTV ${P(port.pLtv,0)} — review refinancing options`);
  a("stress","Run stress test scenario to understand downside");
  a("mtd","Ensure Making Tax Digital compliance");
  a("annual","Schedule annual portfolio review with accountant");
  return items;
}

// ─── ACCOUNTANT PREP ──────────────────────────────────────────────────────
function genPrep(props,ms,port,insights){const L=[];L.push("TAXFLOW AI — ACCOUNTANT MEETING PREP");L.push("=".repeat(45));L.push(`Date: ${new Date().toLocaleDateString("en-GB")}`);L.push(`Portfolio: ${port.activeCnt} active properties, ${£(port.tpv)} value\n`);L.push("SUMMARY");L.push(`Income: ${£(port.tri)}/yr | Costs: ${£(port.toc)}/yr (${P(port.pExpR)}) | Finance: ${£(port.tfc)}/yr`);L.push(`Surplus: ${£(port.tos)}/yr | Cash flow: ${£(port.tcf)}/yr | LTV: ${P(port.pLtv,0)}`);L.push(`Ownership: ${port.persCnt} personal, ${port.corpCnt} corporate\n`);if(port.persCnt>0){L.push("SECTION 24 (Personal Properties)");ms.filter(m=>m.s24).forEach(m=>{L.push(`  ${m.pname}: profit ${£(m.s24.rpbc)}, interest ${£(m.s24.interest)}, credit ${£(m.s24.brc)}, S24 cost@40%: ${£(m.s24.s24cost40)}`)});L.push("")}L.push("KEY FINDINGS");insights.filter(i=>i.sev==="critical"||i.sev==="warning").slice(0,6).forEach(i=>{L.push(`[${i.sev.toUpperCase()}] ${i.title}`);L.push(`  ${i.text}`);if(i.aq)L.push(`  → ${i.aq}`);L.push("")});L.push("QUESTIONS");const qs=[...new Set(insights.filter(i=>i.aq).map(i=>i.aq))];qs.forEach((q,i)=>L.push(`${i+1}. ${q}`));L.push(`\n${DISC}`);return L.join("\n")}

// ─── INSIGHTS (v3.1: fixed dedup, safe formatting) ───────────────────────
const THEMES={cashflow:{l:"Cash Flow",c:"#B91C1C"},finance:{l:"Finance",c:"#92400E"},structure:{l:"Ownership",c:"#1E40AF"},concentration:{l:"Concentration",c:"#7C3AED"},weakness:{l:"Weak Assets",c:"#DC2626"},resilience:{l:"Resilience",c:"#0F766E"},efficiency:{l:"Efficiency",c:"#B45309"},positive:{l:"Strengths",c:"#166534"}};

let _n=0;const mid=()=>`i-${++_n}`;
function gi(ps,ms,port,rk){_n=0;const ins=[];const sv={critical:0,warning:1,info:2,positive:3};const sc=(s,imp,comp)=>{let v=(3-(sv[s]??2))*10;if(comp)v+=5;if(imp)v+=3;return v};

for(const m of ms){
  if(rk&&ms.length>=3){
    if(rk.mostRateSensitive?.pid===m.pid&&m.intR>25)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Most Rate-Sensitive in Portfolio",sev:"warning",theme:"resilience",subcat:"benchmark",text:`${m.pname}: highest interest burden at ${P(m.intR)} (median: ${P(rk.medIntR)}).`,why:"Most affected by rate increases.",aq:"If rates rise 1–2%, what happens to this property?",dp:[`Burden: ${P(m.intR)}`,`Median: ${P(rk.medIntR)}`],impact:null,compound:false,importance:sc("warning",0,0)});
    if(rk.costliest?.pid===m.pid&&m.expR>rk.medExpR+10)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Highest Cost Ratio in Portfolio",sev:"info",theme:"efficiency",subcat:"benchmark",text:`${m.pname}: ${P(m.expR)} costs, ${P(m.expR-rk.medExpR)} above median of ${P(rk.medExpR)}.`,why:"Above your own portfolio norm.",aq:"Review this property's costs?",dp:[`Ratio: ${P(m.expR)}`,`Median: ${P(rk.medExpR)}`],impact:null,compound:false,importance:sc("info",0,0)});
    if(rk.bestYield?.pid===m.pid)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Best Yield in Portfolio",sev:"positive",theme:"positive",subcat:"benchmark",text:`${m.pname}: strongest at ${P(m.gY,2)} (median: ${P(rk.medGY,2)}).`,why:"Understand what's working.",aq:null,dp:[`Yield: ${P(m.gY,2)}`],impact:null,compound:false,importance:sc("positive",0,0)});
    if(rk.worstCF?.pid===m.pid&&m.negCF)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Most Fragile — Worst Cash Flow",sev:"critical",theme:"weakness",subcat:"benchmark",text:`${m.pname}: weakest at ${£(m.cf)}/yr (median: ${£(rk.medCF)}).`,why:"Defines portfolio fragility.",aq:"Restructure or dispose?",dp:[`CF: ${£(m.cf)}`,`Median: ${£(rk.medCF)}`],impact:`${£(Math.abs(m.cf))}/yr`,compound:false,importance:sc("critical",1,0)});
  }

  if(m.ri>0&&m.expR>=TH.EXP_C){const ex=m.oc-m.ri*0.35;ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Very High Costs",sev:"critical",theme:"efficiency",subcat:"threshold",text:`${m.pname}: ${P(m.expR)} of income (typical: 25–40%).`,why:"Erodes returns.",aq:"Review expense breakdown?",dp:[`Costs: ${£(m.oc)}`,`Ratio: ${P(m.expR)}`],impact:ex>0?`~${£(ex)}/yr above 35%`:null,compound:false,importance:sc("critical",ex>0,0)})}
  else if(m.ri>0&&m.expR>=TH.EXP_H)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Elevated Costs",sev:"warning",theme:"efficiency",subcat:"threshold",text:`${m.pname}: ${P(m.expR)} of income.`,why:"Above typical range.",aq:"All deductions claimed?",dp:[`Ratio: ${P(m.expR)}`],impact:null,compound:false,importance:sc("warning",0,0)});

  if(m.ri>0&&m.intR>=TH.INT_C)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Finance Dominating Income",sev:"critical",theme:"finance",subcat:"threshold",text:`${m.pname}: interest = ${P(m.intR)} of income.`,why:"Rate sensitivity extreme.",aq:"Refinancing options?",dp:[`Interest: ${£(m.fc)}/yr`],impact:`${£(m.fc)}/yr`,compound:false,importance:sc("critical",1,0)});

  if(m.ltv>=TH.LTV_C)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Very High Leverage",sev:"critical",theme:"resilience",subcat:"threshold",text:`${m.pname}: LTV ${P(m.ltv,0)}.`,why:"Limits refinancing, increases risk.",aq:"Exposure if values fell 10–15%?",dp:[`LTV: ${P(m.ltv,0)}`],impact:null,compound:false,importance:sc("critical",0,0)});
  else if(m.ltv>=TH.LTV_H)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Elevated Leverage",sev:"warning",theme:"resilience",subcat:"threshold",text:`${m.pname}: LTV ${P(m.ltv,0)}.`,why:"May affect terms.",aq:null,dp:[`LTV: ${P(m.ltv,0)}`],impact:null,compound:false,importance:sc("warning",0,0)});

  if(m.s24&&m.s24.s24cost40>500)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Section 24 Tax Cost",sev:"warning",theme:"structure",subcat:"threshold",text:`${m.pname}: interest ${£(m.s24.interest)}/yr, credit ${£(m.s24.brc)}, extra cost ~${£(m.s24.s24cost40)}/yr at 40%.`,why:"Biggest tax change for UK personal landlords.",aq:"Actual S24 position? Incorporation?",dp:[`Profit: ${£(m.s24.rpbc)}`,`S24 cost: ${£(m.s24.s24cost40)}`],impact:`~${£(m.s24.s24cost40)}/yr`,compound:false,importance:sc("warning",1,0)});

  if(m.gY>=7&&m.expR<35&&!m.negCF)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Strong Performance",sev:"positive",theme:"positive",subcat:"threshold",text:`${m.pname}: ${P(m.gY,2)} yield, ${P(m.expR)} costs, positive CF.`,why:"Well-performing asset.",aq:null,dp:[`Yield: ${P(m.gY,2)}`],impact:null,compound:false,importance:sc("positive",0,0)});

  // Compounds
  if(m.own==="personal"&&m.intR>=30&&m.ri>8000&&m.s24&&m.s24.s24cost40>200)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Section 24 Squeeze",sev:"critical",theme:"structure",subcat:"compound",text:`${m.pname}: personal + ${P(m.intR)} interest + ${£(m.ri)}/yr. Taxed on ${£(m.s24.rpbc)} with 20% credit on ${£(m.s24.interest)}.`,why:"Most common pattern for unexpected UK landlord tax costs.",aq:"Would incorporation reduce overall position?",dp:[`S24 cost: ${£(m.s24.s24cost40)}/yr`],impact:`~${£(m.s24.s24cost40)}/yr`,compound:true,importance:sc("critical",1,1)});

  if(m.negCF&&m.expR>=40&&m.gY<5)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"Cash Drain: Low Yield + High Costs",sev:"critical",theme:"cashflow",subcat:"compound",text:`${m.pname}: ${£(m.cf)}/yr deficit, ${P(m.expR)} costs, ${P(m.gY,2)} yield.`,why:"Only justified by capital growth.",aq:"Dispose vs restructure?",dp:[`CF: ${£(m.cf)}`,`Costs: ${P(m.expR)}`],impact:`${£(Math.abs(m.cf))}/yr`,compound:true,importance:sc("critical",1,1)});

  if(m.ltv>=70&&m.negCF)ins.push({id:mid(),pid:m.pid,pn:m.pname,title:"High Leverage + Negative CF",sev:"critical",theme:"resilience",subcat:"compound",text:`${m.pname}: ${P(m.ltv,0)} LTV + ${£(m.cf)}/yr deficit.`,why:"Subsidising while exposed.",aq:"Risk if rates rise further?",dp:[`LTV: ${P(m.ltv,0)}`,`CF: ${£(m.cf)}`],impact:null,compound:true,importance:sc("critical",0,1)});
}

// Portfolio
if(ms.length>=2&&port.tri>0)for(const m of ms){if((m.ri/port.tri)*100>=50){ins.push({id:mid(),pid:null,pn:null,title:"Concentration Risk",sev:"warning",theme:"concentration",subcat:"portfolio",text:`${m.pname} = ${P((m.ri/port.tri)*100,0)} of income.`,why:"Single-asset dependency.",aq:"Diversification strategy?",dp:[`Share: ${P((m.ri/port.tri)*100,0)}`],impact:`${£(m.ri)}/yr at risk`,compound:false,importance:sc("warning",1,0)});break}}

const wk=ms.filter(m=>m.negCF);if(wk.length>0&&wk.length<ms.length){const dr=wk.reduce((s,m)=>s+m.cf,0);const st=ms.filter(m=>!m.negCF).reduce((s,m)=>s+m.cf,0);if(st>0&&Math.abs(dr)>st*0.3)ins.push({id:mid(),pid:null,pn:null,title:"Weak Assets Dragging Portfolio",sev:"warning",theme:"weakness",subcat:"compound",text:`${wk.length} properties: ${£(dr)}/yr drag (${wk.map(w=>w.pname).join(", ")}).`,why:"Fragility from underperformers.",aq:"Review weakest?",dp:wk.map(w=>`${w.pname}: ${£(w.cf)}`),impact:`${£(Math.abs(dr))}/yr drag`,compound:true,importance:sc("warning",1,1)})}

if(port.persCnt>0&&port.corpCnt>0)ins.push({id:mid(),pid:null,pn:null,title:"Mixed Ownership",sev:"info",theme:"structure",subcat:"portfolio",text:`${port.persCnt} personal + ${port.corpCnt} corporate.`,why:"Different tax regimes.",aq:"Is mix optimal?",dp:[],impact:null,compound:false,importance:sc("info",0,0)});

ins.sort((a,b)=>(b.importance||0)-(a.importance||0));
// FIX #6: dedup key uses theme+subcat, not just theme
const seen=new Set();return ins.filter(i=>{if(!i.pid)return true;const k=`${i.pid}-${i.theme}-${i.subcat}`;if(seen.has(k))return false;seen.add(k);return true})}

// ─── SEED ─────────────────────────────────────────────────────────────────
const SEED=[{id:"p1",name:"Manchester Flat",addressLabel:"14 Northern Quarter, M1",ownershipType:"personal",purchasePrice:185000,estimatedCurrentValue:210000,annualGrossRent:12600,annualOperatingExpenses:2800,annualMortgageInterest:5920,annualPrincipalRepayment:2400,mortgageBalance:148000,estimatedCapex:1500,managementFees:1260,voidAllowance:630,otherDeductibleCosts:350,notes:""},{id:"p2",name:"Birmingham Terrace",addressLabel:"7 Jewellery Quarter, B18",ownershipType:"personal",purchasePrice:155000,estimatedCurrentValue:175000,annualGrossRent:10800,annualOperatingExpenses:3200,annualMortgageInterest:4650,annualPrincipalRepayment:2100,mortgageBalance:124000,estimatedCapex:3500,managementFees:0,voidAllowance:900,otherDeductibleCosts:200,notes:""},{id:"p3",name:"Leeds HMO",addressLabel:"22 Headingley Lane, LS6",ownershipType:"company",purchasePrice:280000,estimatedCurrentValue:310000,annualGrossRent:28800,annualOperatingExpenses:8500,annualMortgageInterest:10850,annualPrincipalRepayment:3600,mortgageBalance:217000,estimatedCapex:4000,managementFees:4320,voidAllowance:2400,otherDeductibleCosts:1200,notes:""},{id:"p4",name:"London Studio",addressLabel:"91 Camberwell Rd, SE5",ownershipType:"personal",purchasePrice:320000,estimatedCurrentValue:295000,annualGrossRent:13200,annualOperatingExpenses:4100,annualMortgageInterest:11200,annualPrincipalRepayment:3000,mortgageBalance:280000,estimatedCapex:500,managementFees:1584,voidAllowance:1100,otherDeductibleCosts:600,notes:""}];
const blankP=(n)=>({id:`p-${Date.now()}-${n}`,name:"",addressLabel:"",ownershipType:"personal",purchasePrice:0,estimatedCurrentValue:0,annualGrossRent:0,annualOperatingExpenses:0,annualMortgageInterest:0,annualPrincipalRepayment:0,mortgageBalance:0,estimatedCapex:0,managementFees:0,voidAllowance:0,otherDeductibleCosts:0,notes:""});

// ─── PERSISTENCE ──────────────────────────────────────────────────────────
function load(){try{const r=localStorage.getItem(SK);return r?JSON.parse(r):null}catch{return null}}
function save(d){try{localStorage.setItem(SK,JSON.stringify({...d,lastSaved:new Date().toISOString()}))}catch{}}

// ─── PALETTE ──────────────────────────────────────────────────────────────
const C={bg:"#F7F6F3",sf:"#FFFFFF",sa:"#F0EFEB",bd:"#E4E1D9",t1:"#171717",t2:"#525252",t3:"#8B8B8B",ac:"#1B4332",al:"#2D6A4F",abg:"rgba(27,67,50,0.05)",abd:"rgba(27,67,50,0.15)",red:"#B91C1C",rbg:"rgba(185,28,28,0.04)",rbd:"rgba(185,28,28,0.12)",amb:"#92400E",ambg:"rgba(146,64,14,0.04)",ambd:"rgba(146,64,14,0.12)",blu:"#1E40AF",blbg:"rgba(30,64,175,0.04)",blbd:"rgba(30,64,175,0.12)",grn:"#166534",gbg:"rgba(22,101,52,0.04)",gbd:"rgba(22,101,52,0.12)"};
const SEV={critical:{c:C.red,bg:C.rbg,bd:C.rbd,tag:"CRITICAL"},warning:{c:C.amb,bg:C.ambg,bd:C.ambd,tag:"ATTENTION"},info:{c:C.blu,bg:C.blbg,bd:C.blbd,tag:"INSIGHT"},positive:{c:C.grn,bg:C.gbg,bd:C.gbd,tag:"POSITIVE"}};
const HLC={critical:C.red,warning:C.amb,info:C.blu,positive:C.grn};

// ─── UI COMPONENTS ────────────────────────────────────────────────────────
const bI={background:C.sf,border:`1px solid ${C.bd}`,borderRadius:8,padding:"10px 14px",fontSize:14,color:C.t1,outline:"none",width:"100%",fontFamily:"inherit"};

// FIX #8: Input fields clamp negatives for financial values
function Fld({label,value,onChange,type="text",prefix,placeholder,help}){
  const handleChange=(v)=>{if(type==="number"){const n=parseFloat(v);if(!isNaN(n)&&n<0&&prefix==="£")return onChange("0")}onChange(v)};
  return<div style={{display:"flex",flexDirection:"column",gap:4}}><label style={{fontSize:11,fontWeight:600,color:C.t3,textTransform:"uppercase",letterSpacing:"0.06em"}}>{label}</label><div style={{position:"relative"}}>{prefix&&<span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:C.t3,fontSize:14,pointerEvents:"none"}}>{prefix}</span>}<input type={type} value={value} onChange={e=>handleChange(e.target.value)} placeholder={placeholder||""} min={type==="number"&&prefix==="£"?"0":undefined} style={{...bI,paddingLeft:prefix?28:14}} /></div>{help&&<div style={{fontSize:10,color:C.t3}}>{help}</div>}</div>}

function Sel({label,value,onChange,options}){return<div style={{display:"flex",flexDirection:"column",gap:4}}><label style={{fontSize:11,fontWeight:600,color:C.t3,textTransform:"uppercase",letterSpacing:"0.06em"}}>{label}</label><select value={value} onChange={e=>onChange(e.target.value)} style={{...bI,cursor:"pointer",appearance:"none"}}>{options.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}</select></div>}
function Cd({children,style={}}){return<div style={{background:C.sf,border:`1px solid ${C.bd}`,borderRadius:12,padding:24,...style}}>{children}</div>}

// FIX #2: Stat now properly shows negative sign via £ formatter
function St({label,value,sub,neg,sm,formula}){return<div style={{flex:1,minWidth:sm?100:130}}><div style={{fontSize:10,fontWeight:500,color:C.t3,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:4}}>{label}</div><div style={{fontSize:sm?15:20,fontWeight:600,color:neg?C.red:C.t1,fontFamily:"'SF Mono',monospace",letterSpacing:"-0.02em"}}>{value}</div>{sub&&<div style={{fontSize:10,color:C.t3,marginTop:2}}>{sub}</div>}{formula&&<div style={{fontSize:9,color:C.t3,marginTop:2,fontStyle:"italic"}}>{formula}</div>}</div>}
function Dc(){return<div style={{padding:"10px 16px",borderRadius:8,background:C.sa,border:`1px solid ${C.bd}`,fontSize:11,color:C.t3,textAlign:"center",lineHeight:1.4}}>⚖️ {DISC}</div>}

function InsCard({ins,idx}){const[open,setOpen]=useState(false);const s=SEV[ins.sev]||SEV.info;const th=THEMES[ins.theme];return<div onClick={()=>setOpen(!open)} style={{background:s.bg,border:`1px solid ${s.bd}`,borderRadius:10,padding:"14px 18px",cursor:"pointer",animation:`fi 0.3s ease ${idx*0.03}s both`}}><div style={{display:"flex",alignItems:"center",gap:6,marginBottom:5,flexWrap:"wrap"}}><span style={{fontSize:8,fontWeight:700,color:s.c,textTransform:"uppercase",letterSpacing:"0.1em",padding:"2px 6px",borderRadius:4,background:`${s.c}10`}}>{s.tag}</span>{ins.compound&&<span style={{fontSize:8,fontWeight:600,color:C.t3,padding:"2px 5px",borderRadius:4,background:C.sa,border:`1px solid ${C.bd}`}}>COMPOUND</span>}{th&&<span style={{fontSize:8,color:th.c,fontWeight:600}}>· {th.l}</span>}{ins.pn&&<span style={{fontSize:10,color:C.t3}}>· {ins.pn}</span>}{ins.impact&&<span style={{marginLeft:"auto",fontSize:11,fontWeight:600,color:s.c,fontFamily:"monospace"}}>{ins.impact}</span>}</div><div style={{fontSize:13,fontWeight:600,color:C.t1,marginBottom:3}}>{ins.title}</div><div style={{fontSize:12,color:C.t2,lineHeight:1.55}}>{ins.text}</div>{open&&<div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${s.bd}`,animation:"fi 0.15s ease"}}><div style={{fontSize:11,fontWeight:600,color:C.t2,marginBottom:2}}>Why this matters</div><div style={{fontSize:12,color:C.t2,lineHeight:1.55,marginBottom:8}}>{ins.why}</div>{ins.aq&&<div style={{fontSize:12,color:C.ac,fontStyle:"italic",padding:"7px 11px",background:C.abg,borderRadius:6,border:`1px solid ${C.abd}`,marginBottom:8}}>Ask your adviser: "{ins.aq}"</div>}{ins.dp?.length>0&&<div style={{fontSize:10,color:C.t3,marginBottom:6}}>Data: {ins.dp.join(" · ")}</div>}<div style={{fontSize:9,color:C.t3,fontStyle:"italic"}}>{DISC}</div></div>}<div style={{fontSize:9,color:C.t3,marginTop:4}}>{open?"▴ Less":"▾ Why · Adviser question · Data"}</div></div>}

// ─── ONBOARDING ───────────────────────────────────────────────────────────
function Onboard({onDone}){const[step,setStep]=useState(0);const steps=[{t:"Welcome to TaxFlow AI",s:"Portfolio intelligence for UK landlords",b:"Understand patterns in your property finances — costs, leverage, yield, and ownership structure impact. Prepare better questions for your accountant.",d:"Built for landlords with 1–20 properties."},{t:"What you'll provide",s:"Property financial data",b:"For each property: rent, expenses, interest, principal, management fees, voids, and values. Estimates work — refine later.",d:"All data stored locally in your browser."},{t:"What this does — and doesn't",s:"Important",b:"Identifies patterns, models Section 24, ranks properties, runs scenarios. Helps prepare accountant conversations.",d:"Does NOT provide tax, legal, or financial advice. All figures are illustrative. Always consult a qualified professional."}];const st=steps[step];return<div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Helvetica Neue',-apple-system,sans-serif",padding:24}}><div style={{maxWidth:500,width:"100%",animation:"fi 0.4s ease"}}><div style={{display:"flex",alignItems:"center",gap:9,marginBottom:28}}><div style={{width:28,height:28,borderRadius:6,background:C.ac,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:10,fontWeight:700}}>TF</div><div><span style={{fontSize:15,fontWeight:700}}>TaxFlow</span> <span style={{fontSize:15,color:C.al}}>AI</span></div></div><div style={{display:"flex",gap:5,marginBottom:24}}>{steps.map((_,i)=><div key={i} style={{flex:1,height:3,borderRadius:2,background:i<=step?C.ac:C.bd}} />)}</div><Cd style={{padding:28}}><div style={{fontSize:10,fontWeight:600,color:C.t3,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:6}}>Step {step+1} of {steps.length}</div><h2 style={{fontSize:20,fontWeight:700,marginBottom:3}}>{st.t}</h2><p style={{fontSize:13,color:C.al,fontWeight:500,marginBottom:14}}>{st.s}</p><p style={{fontSize:13,color:C.t2,lineHeight:1.7,marginBottom:10}}>{st.b}</p><p style={{fontSize:12,color:C.t3,lineHeight:1.5,padding:"8px 12px",background:C.sa,borderRadius:8,border:`1px solid ${C.bd}`}}>{st.d}</p></Cd><div style={{display:"flex",justifyContent:"space-between",marginTop:18}}><button onClick={()=>step>0&&setStep(step-1)} style={{padding:"9px 18px",borderRadius:8,border:`1px solid ${C.bd}`,background:C.sf,color:C.t2,fontSize:13,cursor:step>0?"pointer":"default",opacity:step>0?1:0.3,fontFamily:"inherit"}}>Back</button>{step<steps.length-1?<button onClick={()=>setStep(step+1)} style={{padding:"9px 22px",borderRadius:8,border:"none",background:C.ac,color:"#fff",fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Continue</button>:<button onClick={onDone} style={{padding:"9px 22px",borderRadius:8,border:"none",background:C.ac,color:"#fff",fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>I understand — begin</button>}</div></div></div>}

// ─── MAIN ─────────────────────────────────────────────────────────────────
export default function TaxFlowAI(){
  const sv=load();
  const[onb,setOnb]=useState(sv?.onboardingComplete??false);
  const[pg,setPg]=useState("overview");
  const[props,setProps]=useState(sv?.properties??SEED);
  const[editId,setEditId]=useState(null);
  const[aiText,setAiText]=useState("");
  const[aiLoad,setAiLoad]=useState(false);
  const[scPreset,setScPreset]=useState(null);
  const[checkDone,setCheckDone]=useState(sv?.checkDone??{});
  const[saveInd,setSaveInd]=useState(false);
  const[showPrep,setShowPrep]=useState(false);

  const ms=useMemo(()=>props.filter(p=>p.annualGrossRent>0).map(cm),[props]);
  const port=useMemo(()=>cp(props,ms),[props,ms]);
  const rk=useMemo(()=>rank(ms),[ms]);
  const hl=useMemo(()=>headline(ms,port,rk),[ms,port,rk]);
  const insights=useMemo(()=>gi(props,ms,port,rk),[props,ms,port,rk]);
  const checklist=useMemo(()=>genChecklist(props,ms,port,rk),[props,ms,port,rk]);
  const worstId=rk?.worstCF?.pid||props[0]?.id;
  const scResult=useMemo(()=>{if(!scPreset)return null;const pr=PRESETS.find(p=>p.id===scPreset);if(!pr)return null;const r=runPreset(pr,props,worstId);return{name:pr.name,desc:pr.desc,base:port,proj:r.port}},[scPreset,props,port,worstId]);
  const projection=useMemo(()=>proj3(props),[props]);

  useEffect(()=>{save({properties:props,onboardingComplete:onb,checkDone});setSaveInd(true);const t=setTimeout(()=>setSaveInd(false),1500);return()=>clearTimeout(t)},[props,onb,checkDone]);

  const upd=(id,k,v)=>setProps(ps=>ps.map(p=>p.id===id?{...p,[k]:["name","addressLabel","notes","ownershipType"].includes(k)?v:(parseFloat(v)||0)}:p));
  const addP=()=>{const n=blankP(props.length+1);n.name=`Property ${props.length+1}`;setProps([...props,n]);setEditId(n.id)};
  const delP=id=>{setProps(ps=>ps.filter(p=>p.id!==id));if(editId===id)setEditId(null)};
  const critCnt=insights.filter(i=>i.sev==="critical"||i.sev==="warning").length;
  const compCnt=insights.filter(i=>i.compound).length;

  const reqAi=async()=>{setAiLoad(true);try{const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1500,system:`You are TaxFlow AI for UK property investors. Never give advice. Hedge language. Reference Section 24. End with: "${DISC}"`,messages:[{role:"user",content:`UK portfolio: ${port.activeCnt} props, ${£(port.tri)} rent, ${P(port.pLtv,0)} LTV. Personal: ${port.persCnt} (S24 interest ${£(port.tPersInt)}). Corp: ${port.corpCnt}. 4-5 observations.`}]})});const d=await r.json();setAiText(d.content?.map(b=>b.text||"").join("\n")||"")}catch{setAiText(`1. Section 24\nPersonal properties: ${£(port.tPersInt)}/yr interest, 20% credit only.\n→ Ask: "What is my actual S24 position?"\n\n2. Cash Flow\n${£(port.tcf)}/yr across ${port.activeCnt} properties.\n→ Ask: "Should I maintain reserves?"\n\n${DISC}`)}setAiLoad(false)};

  if(!onb)return<><style>{`@keyframes fi{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}*{box-sizing:border-box;margin:0;padding:0}`}</style><Onboard onDone={()=>setOnb(true)}/></>;

  const prep=showPrep?genPrep(props,ms,port,insights):"";
  const nav=[{id:"overview",l:"Overview",ic:"◻"},{id:"properties",l:"Properties",ic:"⌂"},{id:"insights",l:"Insights",ic:"◈"},{id:"scenarios",l:"Scenarios",ic:"⇄"},{id:"review",l:"Review",ic:"☑"},{id:"settings",l:"Settings",ic:"⚙"}];

  return<div style={{minHeight:"100vh",background:C.bg,fontFamily:"'Helvetica Neue',-apple-system,sans-serif",color:C.t1}}>
    <style>{`@keyframes fi{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}*{box-sizing:border-box;margin:0;padding:0}input::placeholder{color:${C.t3}}::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:${C.bd};border-radius:3px}`}</style>

    {/* SIDEBAR */}
    <div style={{position:"fixed",left:0,top:0,bottom:0,width:210,background:C.sf,borderRight:`1px solid ${C.bd}`,display:"flex",flexDirection:"column",zIndex:50}}>
      <div style={{padding:"18px 14px 14px",borderBottom:`1px solid ${C.bd}`}}><div style={{display:"flex",alignItems:"center",gap:8}}><div style={{width:24,height:24,borderRadius:5,background:C.ac,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:9,fontWeight:700}}>TF</div><div><span style={{fontSize:13,fontWeight:700}}>TaxFlow</span> <span style={{fontSize:13,color:C.al}}>AI</span></div></div></div>
      <nav style={{flex:1,padding:"8px 6px"}}>{nav.map(n=><button key={n.id} onClick={()=>setPg(n.id)} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:"7px 10px",borderRadius:6,border:"none",marginBottom:1,background:pg===n.id?C.abg:"transparent",color:pg===n.id?C.ac:C.t2,fontSize:12,fontWeight:pg===n.id?600:400,cursor:"pointer",fontFamily:"inherit",textAlign:"left"}}><span style={{fontSize:11,opacity:0.6,width:14}}>{n.ic}</span>{n.l}{n.id==="insights"&&critCnt>0&&<span style={{marginLeft:"auto",fontSize:8,fontWeight:700,background:C.red,color:"#fff",borderRadius:10,padding:"1px 5px"}}>{critCnt}</span>}</button>)}</nav>
      <div style={{padding:"10px 14px",borderTop:`1px solid ${C.bd}`}}>{saveInd&&<div style={{fontSize:9,color:C.grn,marginBottom:3,animation:"fi 0.2s ease"}}>✓ Saved</div>}<div style={{fontSize:9,color:C.t3}}>Informational only</div></div>
    </div>

    <main style={{marginLeft:210,padding:"24px 30px",maxWidth:1020}}>

      {/* ═══ OVERVIEW ═══ */}
      {pg==="overview"&&<div style={{animation:"fi 0.3s ease"}}>
        <div style={{padding:"14px 18px",borderRadius:10,background:`${HLC[hl.type]}08`,border:`1px solid ${HLC[hl.type]}20`,marginBottom:18}}><div style={{fontSize:13,fontWeight:600,color:HLC[hl.type],lineHeight:1.5}}>{hl.text}</div><div style={{fontSize:10,color:C.t3,marginTop:4}}>Portfolio headline · {DISC}</div></div>

        <h1 style={{fontSize:21,fontWeight:700,marginBottom:3}}>Overview</h1>
        <p style={{fontSize:12,color:C.t2,marginBottom:18}}>{port.activeCnt} active properties · {£(port.tpv)} value{port.cnt!==port.activeCnt?` · ${port.cnt-port.activeCnt} incomplete`:""}</p>

        <Cd style={{marginBottom:12}}><div style={{display:"flex",flexWrap:"wrap",gap:16}}>
          <St label="Rental Income" value={£(port.tri)} sub="/yr" formula="Gross rent"/>
          <St label="Operating Costs" value={£(port.toc)} sub={P(port.pExpR)+" of income"}/>
          <St label="Finance Costs" value={£(port.tfc)} sub={P(port.pIntR)+" of income"}/>
          <St label="Operating Surplus" value={£(port.tos)} neg={port.tos<0} formula="Income − opex"/>
          <St label="Cash Flow" value={£(port.tcf)} neg={port.tcf<0} formula="After all costs"/>
        </div></Cd>

        {/* S24 table — FIX #1/#2: proper negative display */}
        {ms.some(m=>m.s24)&&<Cd style={{marginBottom:12,border:`1px solid ${C.ambd}`,background:C.ambg}}>
          <div style={{fontSize:12,fontWeight:700,color:C.amb,marginBottom:8}}>Section 24 — Personal Properties</div>
          <div style={{fontSize:10,color:C.t3,marginBottom:10}}>Interest not deductible. 20% credit instead. Illustrative.</div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}><thead><tr style={{borderBottom:`1px solid ${C.ambd}`}}>{["Property","Rental Profit","Interest","20% Credit","Tax @40%","S24 Extra Cost"].map(h=><th key={h} style={{textAlign:"left",padding:"5px",fontSize:9,fontWeight:600,color:C.t3,textTransform:"uppercase"}}>{h}</th>)}</tr></thead><tbody>{ms.filter(m=>m.s24).map(m=><tr key={m.pid} style={{borderBottom:`1px solid ${C.bd}`}}>
            <td style={{padding:"6px 5px",fontWeight:500}}>{m.pname}</td>
            <td style={{padding:"6px 5px",fontFamily:"monospace",color:m.s24.rpbc<0?C.red:C.t1}}>{£(m.s24.rpbc)}</td>
            <td style={{padding:"6px 5px",fontFamily:"monospace"}}>{£(m.s24.interest)}</td>
            <td style={{padding:"6px 5px",fontFamily:"monospace",color:C.grn}}>{£(m.s24.brc)}</td>
            <td style={{padding:"6px 5px",fontFamily:"monospace"}}>{£(m.s24.taxAt40)}</td>
            <td style={{padding:"6px 5px",fontFamily:"monospace",fontWeight:600,color:m.s24.s24cost40>0?C.red:C.t1}}>{£(m.s24.s24cost40)}</td>
          </tr>)}</tbody></table>
        </Cd>}

        {rk&&<Cd style={{marginBottom:12}}>
          <div style={{fontSize:12,fontWeight:700,marginBottom:10}}>Property Rankings</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,fontSize:12}}>
            <div style={{padding:"8px 10px",background:C.gbg,borderRadius:6,border:`1px solid ${C.gbd}`}}><div style={{fontSize:9,color:C.grn,fontWeight:600,textTransform:"uppercase",marginBottom:3}}>Best Yield</div><div style={{fontWeight:600}}>{rk.bestYield.pname}</div><div style={{fontSize:11,color:C.t3,fontFamily:"monospace"}}>{P(rk.bestYield.gY,2)}</div></div>
            <div style={{padding:"8px 10px",background:C.rbg,borderRadius:6,border:`1px solid ${C.rbd}`}}><div style={{fontSize:9,color:C.red,fontWeight:600,textTransform:"uppercase",marginBottom:3}}>Weakest Cash Flow</div><div style={{fontWeight:600}}>{rk.worstCF.pname}</div><div style={{fontSize:11,color:C.red,fontFamily:"monospace"}}>{£(rk.worstCF.cf)}/yr</div></div>
            <div style={{padding:"8px 10px",background:C.ambg,borderRadius:6,border:`1px solid ${C.ambd}`}}><div style={{fontSize:9,color:C.amb,fontWeight:600,textTransform:"uppercase",marginBottom:3}}>Most Rate-Sensitive</div><div style={{fontWeight:600}}>{rk.mostRateSensitive.pname}</div><div style={{fontSize:11,color:C.t3,fontFamily:"monospace"}}>{P(rk.mostRateSensitive.intR)} burden</div></div>
            <div style={{padding:"8px 10px",background:C.sa,borderRadius:6,border:`1px solid ${C.bd}`}}><div style={{fontSize:9,color:C.t3,fontWeight:600,textTransform:"uppercase",marginBottom:3}}>Leanest Operations</div><div style={{fontWeight:600}}>{rk.leanest.pname}</div><div style={{fontSize:11,color:C.t3,fontFamily:"monospace"}}>{P(rk.leanest.expR)} costs</div></div>
          </div>
        </Cd>}

        <Cd style={{marginBottom:12}}><div style={{fontSize:12,fontWeight:700,marginBottom:3}}>3-Year Projection (Illustrative)</div><div style={{fontSize:10,color:C.t3,marginBottom:10}}>Assumes 2% rent growth, 3% cost inflation, flat rates. Not a forecast.</div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}><thead><tr style={{borderBottom:`1px solid ${C.bd}`}}>{["","Income","Surplus","Cash Flow","Yield"].map(h=><th key={h} style={{textAlign:"left",padding:"5px",fontSize:9,fontWeight:600,color:C.t3,textTransform:"uppercase"}}>{h}</th>)}</tr></thead>
          <tbody>{projection.map(y=><tr key={y.yr} style={{borderBottom:`1px solid ${C.bd}`,fontWeight:y.yr===0?600:400}}><td style={{padding:"5px"}}>{y.label}</td><td style={{padding:"5px",fontFamily:"monospace"}}>{£(y.ri)}</td><td style={{padding:"5px",fontFamily:"monospace",color:y.os<0?C.red:C.t1}}>{£(y.os)}</td><td style={{padding:"5px",fontFamily:"monospace",color:y.cf<0?C.red:C.t1}}>{£(y.cf)}</td><td style={{padding:"5px",fontFamily:"monospace"}}>{P(y.gY,2)}</td></tr>)}</tbody></table>
        </Cd>

        {insights.length>0&&<Cd><div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}><div style={{fontSize:12,fontWeight:700}}>Top Observations</div><button onClick={()=>setPg("insights")} style={{fontSize:11,color:C.al,background:"none",border:"none",cursor:"pointer",fontFamily:"inherit"}}>All {insights.length} →</button></div><div style={{display:"flex",flexDirection:"column",gap:7}}>{insights.slice(0,3).map((ins,i)=><InsCard key={ins.id} ins={ins} idx={i}/>)}</div></Cd>}
        <div style={{marginTop:12}}><Dc/></div>
      </div>}

      {/* ═══ PROPERTIES ═══ */}
      {pg==="properties"&&<div style={{animation:"fi 0.3s ease"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}><div><h1 style={{fontSize:21,fontWeight:700,marginBottom:2}}>Properties</h1><p style={{fontSize:12,color:C.t2}}>{props.length} total{port.activeCnt<props.length?` · ${props.length-port.activeCnt} need data`:""}</p></div><button onClick={addP} style={{padding:"8px 16px",borderRadius:8,border:"none",background:C.ac,color:"#fff",fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>+ Add</button></div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {props.map(p=>{const m=ms.find(x=>x.pid===p.id);const ed=editId===p.id;const incomplete=!p.annualGrossRent;return<Cd key={p.id} style={{border:ed?`1.5px solid ${C.abd}`:incomplete?`1px dashed ${C.amb}`:`1px solid ${C.bd}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:ed?14:0}}>
              <div><div style={{fontSize:14,fontWeight:600,marginBottom:1}}>{p.name||"Unnamed"}{incomplete&&<span style={{fontSize:10,color:C.amb,marginLeft:8}}>needs data</span>}</div><div style={{fontSize:10,color:C.t3}}>{p.addressLabel||"—"} · {OWN[p.ownershipType]}</div></div>
              <div style={{display:"flex",gap:5,alignItems:"center"}}>{!ed&&m&&<div style={{display:"flex",gap:10,marginRight:8}}><St sm label="Income" value={£(m.ri)}/><St sm label="CF" value={£(m.cf)} neg={m.negCF}/><St sm label="Yield" value={P(m.gY,1)}/></div>}<button onClick={()=>setEditId(ed?null:p.id)} style={{padding:"4px 10px",borderRadius:6,border:`1px solid ${C.bd}`,background:C.sf,color:C.t2,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>{ed?"Done":"Edit"}</button><button onClick={()=>delP(p.id)} style={{padding:"4px 7px",borderRadius:6,border:`1px solid ${C.rbd}`,background:C.rbg,color:C.red,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>✕</button></div>
            </div>
            {ed&&<div style={{animation:"fi 0.2s ease"}}>
              <div style={{fontSize:10,fontWeight:700,color:C.t3,textTransform:"uppercase",marginBottom:6}}>Details</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:8,marginBottom:12}}>
                <Fld label="Name" value={p.name} onChange={v=>upd(p.id,"name",v)}/><Fld label="Address" value={p.addressLabel} onChange={v=>upd(p.id,"addressLabel",v)}/>
                <Sel label="Ownership" value={p.ownershipType} onChange={v=>upd(p.id,"ownershipType",v)} options={[{v:"personal",l:"Personal"},{v:"company",l:"Ltd Company"},{v:"spv",l:"SPV"}]}/>
                <Fld label="Purchase Price" value={p.purchasePrice||""} onChange={v=>upd(p.id,"purchasePrice",v)} prefix="£" type="number"/><Fld label="Current Value" value={p.estimatedCurrentValue||""} onChange={v=>upd(p.id,"estimatedCurrentValue",v)} prefix="£" type="number"/>
              </div>
              <div style={{fontSize:10,fontWeight:700,color:C.t3,textTransform:"uppercase",marginBottom:6}}>Income & Costs</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:8,marginBottom:12}}>
                <Fld label="Annual Rent" value={p.annualGrossRent||""} onChange={v=>upd(p.id,"annualGrossRent",v)} prefix="£" type="number"/>
                <Fld label="Operating Expenses" value={p.annualOperatingExpenses||""} onChange={v=>upd(p.id,"annualOperatingExpenses",v)} prefix="£" type="number" help="Insurance, repairs, maintenance"/>
                <Fld label="Management Fees" value={p.managementFees||""} onChange={v=>upd(p.id,"managementFees",v)} prefix="£" type="number"/>
                <Fld label="Void Allowance" value={p.voidAllowance||""} onChange={v=>upd(p.id,"voidAllowance",v)} prefix="£" type="number"/>
                <Fld label="Other Deductible" value={p.otherDeductibleCosts||""} onChange={v=>upd(p.id,"otherDeductibleCosts",v)} prefix="£" type="number"/>
              </div>
              <div style={{fontSize:10,fontWeight:700,color:C.t3,textTransform:"uppercase",marginBottom:6}}>Finance</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:8,marginBottom:8}}>
                <Fld label="Mortgage Interest" value={p.annualMortgageInterest||""} onChange={v=>upd(p.id,"annualMortgageInterest",v)} prefix="£" type="number" help="Interest only"/>
                <Fld label="Principal Repayment" value={p.annualPrincipalRepayment||""} onChange={v=>upd(p.id,"annualPrincipalRepayment",v)} prefix="£" type="number"/>
                <Fld label="Mortgage Balance" value={p.mortgageBalance||""} onChange={v=>upd(p.id,"mortgageBalance",v)} prefix="£" type="number"/>
              </div>
            </div>}
          </Cd>})}
          {props.length===0&&<Cd style={{textAlign:"center",padding:36}}><div style={{fontSize:24,marginBottom:8}}>⌂</div><div style={{fontSize:13,fontWeight:600,marginBottom:12}}>No properties</div><button onClick={addP} style={{padding:"8px 18px",borderRadius:8,border:"none",background:C.ac,color:"#fff",fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>+ Add</button></Cd>}
        </div>
      </div>}

      {/* ═══ INSIGHTS ═══ */}
      {pg==="insights"&&<div style={{animation:"fi 0.3s ease"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:18}}>
          <div><h1 style={{fontSize:21,fontWeight:700,marginBottom:2}}>Tax Intelligence</h1><p style={{fontSize:12,color:C.t2}}>{insights.length} observations · {compCnt} compound · Ranked</p></div>
          <div style={{display:"flex",gap:6}}>{critCnt>0&&<div style={{padding:"4px 10px",borderRadius:6,background:C.ambg,border:`1px solid ${C.ambd}`,fontSize:11,color:C.amb}}>{critCnt} attention</div>}<button onClick={()=>setShowPrep(!showPrep)} style={{padding:"4px 12px",borderRadius:6,border:`1px solid ${C.abd}`,background:C.abg,color:C.ac,fontSize:11,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>{showPrep?"Hide":"📋 Accountant Prep"}</button></div>
        </div>
        {showPrep&&<Cd style={{marginBottom:14,background:C.sa}}><div style={{fontSize:12,fontWeight:700,marginBottom:8}}>Accountant Prep</div><pre style={{fontSize:11,lineHeight:1.6,color:C.t2,whiteSpace:"pre-wrap",fontFamily:"monospace",maxHeight:400,overflow:"auto",padding:12,background:C.sf,borderRadius:8,border:`1px solid ${C.bd}`}}>{prep}</pre><button onClick={()=>{navigator.clipboard?.writeText(prep)}} style={{marginTop:8,padding:"6px 14px",borderRadius:6,border:`1px solid ${C.bd}`,background:C.sf,color:C.t2,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>Copy to Clipboard</button></Cd>}
        {insights.length>0&&<div style={{display:"flex",gap:5,marginBottom:14,flexWrap:"wrap"}}>{Object.entries(THEMES).map(([k,v])=>{const c=insights.filter(i=>i.theme===k).length;if(!c)return null;return<span key={k} style={{fontSize:10,padding:"3px 8px",borderRadius:5,background:`${v.c}08`,border:`1px solid ${v.c}20`,color:v.c,fontWeight:500}}>{v.l} ({c})</span>})}</div>}
        {insights.length===0?<Cd style={{textAlign:"center",padding:36}}><div style={{fontSize:12,color:C.t3}}>Add property data to generate insights.</div></Cd>:<div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:18}}>{insights.map((ins,i)=><InsCard key={ins.id} ins={ins} idx={i}/>)}</div>}
        <Cd style={{background:`linear-gradient(135deg,${C.sf},${C.sa})`,marginBottom:12}}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}><div><div style={{fontSize:13,fontWeight:700,color:C.ac}}>AI Analysis</div><div style={{fontSize:10,color:C.t3}}>AI-generated, discussion only</div></div><button onClick={reqAi} disabled={aiLoad||ms.length===0} style={{padding:"7px 14px",borderRadius:7,border:`1px solid ${C.abd}`,background:C.abg,color:C.ac,fontSize:11,fontWeight:600,cursor:aiLoad?"wait":"pointer",fontFamily:"inherit",opacity:ms.length===0?0.4:1}}>{aiLoad?"Analysing...":"Generate"}</button></div>{aiText&&<div style={{border:`1px solid ${C.bd}`,borderRadius:8,overflow:"hidden"}}><div style={{padding:"6px 12px",background:C.sa,borderBottom:`1px solid ${C.bd}`,fontSize:9,fontWeight:600,color:C.t3,textTransform:"uppercase"}}>AI-Generated · Discussion Only</div><div style={{padding:14,fontSize:12,lineHeight:1.7,color:C.t2,whiteSpace:"pre-wrap",background:C.sf}}>{aiText}</div></div>}</Cd>
        <Dc/>
      </div>}

      {/* ═══ SCENARIOS ═══ */}
      {pg==="scenarios"&&<div style={{animation:"fi 0.3s ease"}}>
        <h1 style={{fontSize:21,fontWeight:700,marginBottom:2}}>Scenarios</h1><p style={{fontSize:12,color:C.t2,marginBottom:18}}>Model real decisions. All projections illustrative.</p>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:8,marginBottom:18}}>{PRESETS.map(pr=><button key={pr.id} onClick={()=>setScPreset(scPreset===pr.id?null:pr.id)} style={{padding:"10px 12px",borderRadius:8,border:`1px solid ${scPreset===pr.id?C.abd:C.bd}`,background:scPreset===pr.id?C.abg:C.sf,color:scPreset===pr.id?C.ac:C.t1,fontSize:12,fontWeight:scPreset===pr.id?600:400,cursor:"pointer",fontFamily:"inherit",textAlign:"left"}}><div style={{fontWeight:600,marginBottom:2}}>{pr.name}</div><div style={{fontSize:10,color:C.t3}}>{pr.desc}</div></button>)}</div>
        {scResult&&<Cd style={{marginBottom:14}}><div style={{fontSize:13,fontWeight:700,marginBottom:12}}>{scResult.name}</div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}><div><div style={{fontSize:10,color:C.t3,textTransform:"uppercase",marginBottom:8}}>Baseline</div><St sm label="Income" value={£(scResult.base.tri)}/><div style={{height:6}}/><St sm label="Surplus" value={£(scResult.base.tos)} neg={scResult.base.tos<0}/><div style={{height:6}}/><St sm label="Cash Flow" value={£(scResult.base.tcf)} neg={scResult.base.tcf<0}/></div><div><div style={{fontSize:10,color:C.t3,textTransform:"uppercase",marginBottom:8}}>Projected</div><St sm label="Income" value={£(scResult.proj.tri)}/><div style={{height:6}}/><St sm label="Surplus" value={£(scResult.proj.tos)} neg={scResult.proj.tos<0}/><div style={{height:6}}/><St sm label="Cash Flow" value={£(scResult.proj.tcf)} neg={scResult.proj.tcf<0}/></div></div>{(()=>{const d=scResult.proj.tcf-scResult.base.tcf;return<div style={{marginTop:14,padding:14,borderRadius:8,background:d>=0?C.gbg:C.rbg,border:`1px solid ${d>=0?C.gbd:C.rbd}`,textAlign:"center"}}><div style={{fontSize:9,color:C.t3,textTransform:"uppercase",marginBottom:4}}>Cash Flow Impact</div><div style={{fontSize:22,fontWeight:700,color:d>=0?C.grn:C.red,fontFamily:"monospace"}}>{£(d,true)}/yr</div></div>})()}</Cd>}
        <Cd><div style={{fontSize:12,fontWeight:700,marginBottom:3}}>3-Year Projection</div><div style={{fontSize:10,color:C.t3,marginBottom:10}}>2% rent growth, 3% cost inflation, flat rates. Illustrative.</div><table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}><thead><tr style={{borderBottom:`1px solid ${C.bd}`}}>{["","Income","Surplus","Cash Flow","Yield"].map(h=><th key={h} style={{textAlign:"left",padding:"5px",fontSize:9,fontWeight:600,color:C.t3,textTransform:"uppercase"}}>{h}</th>)}</tr></thead><tbody>{projection.map(y=><tr key={y.yr} style={{borderBottom:`1px solid ${C.bd}`,fontWeight:y.yr===0?600:400}}><td style={{padding:"5px"}}>{y.label}</td><td style={{padding:"5px",fontFamily:"monospace"}}>{£(y.ri)}</td><td style={{padding:"5px",fontFamily:"monospace",color:y.os<0?C.red:C.t1}}>{£(y.os)}</td><td style={{padding:"5px",fontFamily:"monospace",color:y.cf<0?C.red:C.t1}}>{£(y.cf)}</td><td style={{padding:"5px",fontFamily:"monospace"}}>{P(y.gY,2)}</td></tr>)}</tbody></table></Cd>
        <div style={{marginTop:12}}><Dc/></div>
      </div>}

      {/* ═══ REVIEW ═══ */}
      {pg==="review"&&<div style={{animation:"fi 0.3s ease"}}>
        <h1 style={{fontSize:21,fontWeight:700,marginBottom:2}}>Portfolio Review</h1><p style={{fontSize:12,color:C.t2,marginBottom:18}}>Track review progress.</p>
        <Cd style={{marginBottom:14}}><div style={{fontSize:12,fontWeight:700,marginBottom:12}}>Checklist</div><div style={{display:"flex",flexDirection:"column",gap:6}}>{checklist.map(item=><div key={item.id} onClick={()=>setCheckDone(prev=>({...prev,[item.id]:!prev[item.id]}))} style={{display:"flex",alignItems:"flex-start",gap:10,padding:"8px 10px",borderRadius:6,cursor:"pointer",background:checkDone[item.id]?C.gbg:"transparent",border:`1px solid ${checkDone[item.id]?C.gbd:C.bd}`}}><div style={{width:18,height:18,borderRadius:4,border:`2px solid ${checkDone[item.id]?C.grn:C.bd}`,background:checkDone[item.id]?C.grn:"transparent",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:11,fontWeight:700,flexShrink:0,marginTop:1}}>{checkDone[item.id]?"✓":""}</div><div><div style={{fontSize:12,color:checkDone[item.id]?C.t3:C.t1,textDecoration:checkDone[item.id]?"line-through":"none",lineHeight:1.4}}>{item.text}</div>{item.pri==="high"&&!checkDone[item.id]&&<div style={{fontSize:9,color:C.red,fontWeight:600,marginTop:2}}>HIGH PRIORITY</div>}</div></div>)}</div><div style={{marginTop:12,fontSize:11,color:C.t3}}>{Object.values(checkDone).filter(Boolean).length} of {checklist.length} complete</div></Cd>
        <Cd style={{marginBottom:14}}><div style={{fontSize:12,fontWeight:700,marginBottom:8}}>Accountant Prep</div><p style={{fontSize:11,color:C.t2,marginBottom:10}}>Generate a summary for your accountant meeting.</p><button onClick={()=>{setPg("insights");setShowPrep(true)}} style={{padding:"7px 16px",borderRadius:7,border:`1px solid ${C.abd}`,background:C.abg,color:C.ac,fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>📋 Generate</button></Cd>
        {rk&&<Cd><div style={{fontSize:12,fontWeight:700,marginBottom:8}}>Watchlist (weakest first)</div>{rk.rankings.byCF.slice().reverse().map((r,i)=><div key={r.pid} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:`1px solid ${C.bd}`,fontSize:12}}><span style={{fontWeight:i===0?600:400,color:r.v<0?C.red:C.t1}}>{i+1}. {r.pn}</span><span style={{fontFamily:"monospace",color:r.v<0?C.red:C.t1}}>{£(r.v)}/yr</span></div>)}</Cd>}
      </div>}

      {/* ═══ SETTINGS ═══ */}
      {pg==="settings"&&<div style={{animation:"fi 0.3s ease"}}>
        <h1 style={{fontSize:21,fontWeight:700,marginBottom:18}}>Settings</h1>
        <Cd style={{marginBottom:10}}><h3 style={{fontSize:13,fontWeight:600,marginBottom:6}}>About</h3><p style={{fontSize:12,color:C.t2,lineHeight:1.6}}>Portfolio intelligence for UK landlords. Section 24, rankings, scenarios. Does NOT provide advice.</p></Cd>
        <Cd><h3 style={{fontSize:13,fontWeight:600,marginBottom:6}}>Data</h3><p style={{fontSize:11,color:C.t3,marginBottom:8}}>Stored locally. AI sends data for insights.</p><div style={{display:"flex",gap:6}}><button onClick={()=>{setProps(SEED);setEditId(null)}} style={{padding:"5px 12px",borderRadius:6,border:`1px solid ${C.bd}`,background:C.sf,color:C.t2,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>Load Sample</button><button onClick={()=>{setProps([]);setEditId(null);setAiText("")}} style={{padding:"5px 12px",borderRadius:6,border:`1px solid ${C.rbd}`,background:C.rbg,color:C.red,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>Clear All</button><button onClick={()=>setOnb(false)} style={{padding:"5px 12px",borderRadius:6,border:`1px solid ${C.bd}`,background:C.sf,color:C.t2,fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>Onboarding</button></div></Cd>
      </div>}
    </main>
  </div>
}
